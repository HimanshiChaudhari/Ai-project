<?php
// index.php
require_once 'includes/config.php';
require_once 'includes/auth.php';
redirectIfNotLoggedIn();

// Get user data
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

// Get room statistics
$roomStats = $pdo->query("SELECT status, COUNT(*) as count FROM rooms GROUP BY status")->fetchAll(PDO::FETCH_ASSOC);

// Get recent reservations
$reservations = $pdo->query("SELECT r.*, rm.room_number, rm.room_type 
                            FROM reservations r 
                            JOIN rooms rm ON r.room_id = rm.id 
                            ORDER BY r.created_at DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HotelAI - Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="dashboard-page">
    <?php include 'includes/header.php'; ?>
    
    <main class="container py-4">
        <div class="row">
            <div class="col-md-3">
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <img src="https://ui-avatars.com/api/?name=<?= urlencode($user['full_name'] ?? $user['username']) ?>&background=random" 
                             class="rounded-circle mb-3" width="100" height="100">
                        <h5><?= htmlspecialchars($user['full_name'] ?? $user['username']) ?></h5>
                        <span class="badge bg-<?= $user['role'] === 'admin' ? 'danger' : ($user['role'] === 'manager' ? 'warning' : 'primary') ?>">
                            <?= ucfirst($user['role']) ?>
                        </span>
                    </div>
                </div>
                
                <div class="card mb-4">
                    <div class="card-header">
                        <h6>Quick Actions</h6>
                    </div>
                    <div class="card-body">
                        <a href="admin/reservations.php?action=create" class="btn btn-success btn-sm w-100 mb-2">
                            <i class="fas fa-plus"></i> New Reservation
                        </a>
                        <?php if (isManager()): ?>
                            <a href="admin/rooms.php" class="btn btn-primary btn-sm w-100 mb-2">
                                <i class="fas fa-door-open"></i> Manage Rooms
                            </a>
                        <?php endif; ?>
                        <?php if (isAdmin()): ?>
                            <a href="admin/staff.php" class="btn btn-info btn-sm w-100 mb-2">
                                <i class="fas fa-users"></i> Manage Staff
                            </a>
                        <?php endif; ?>
                        <a href="profile.php" class="btn btn-secondary btn-sm w-100">
                            <i class="fas fa-user"></i> My Profile
                        </a>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <h6>Room Status</h6>
                    </div>
                    <div class="card-body">
                        <?php foreach ($roomStats as $stat): ?>
                            <div class="d-flex justify-content-between mb-2">
                                <span><?= ucfirst($stat['status']) ?></span>
                                <span class="badge bg-<?= $stat['status'] === 'available' ? 'success' : ($stat['status'] === 'occupied' ? 'danger' : 'warning') ?>">
                                    <?= $stat['count'] ?>
                                </span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            
            <div class="col-md-9">
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5>Recent Reservations</h5>
                        <a href="admin/reservations.php" class="btn btn-sm btn-outline-primary">View All</a>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Room</th>
                                        <th>Guest</th>
                                        <th>Dates</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($reservations as $res): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($res['room_number']) ?> (<?= htmlspecialchars($res['room_type']) ?>)</td>
                                            <td><?= htmlspecialchars($res['guest_name']) ?></td>
                                            <td><?= date('M j', strtotime($res['check_in'])) ?> - <?= date('M j', strtotime($res['check_out'])) ?></td>
                                            <td>
                                                <span class="badge bg-<?= $res['status'] === 'confirmed' ? 'success' : ($res['status'] === 'cancelled' ? 'danger' : 'warning') ?>">
                                                    <?= ucfirst($res['status']) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <a href="admin/reservations.php?action=view&id=<?= $res['id'] ?>" class="btn btn-sm btn-outline-info">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <h5>HotelAI Assistant</h5>
                    </div>
                    <div class="card-body chat-container">
                        <div class="chat-messages" id="chatMessages">
                            <div class="bot-message message">
                                <div class="font-bold mb-1">HotelAI</div>
                                <div>Hello <?= htmlspecialchars($user['full_name'] ?? $user['username']) ?>! How can I assist you with your hotel management today?</div>
                                <div class="flex flex-wrap mt-3">
                                    <button class="quick-action-btn">Check room availability</button>
                                    <button class="quick-action-btn">Create new reservation</button>
                                    <button class="quick-action-btn">View today's check-ins</button>
                                    <button class="quick-action-btn">Generate revenue report</button>
                                </div>
                            </div>
                        </div>
                        
                        <div class="chat-input-area">
                            <form id="chatForm" class="flex gap-2">
                                <input type="text" id="userInput" class="flex-grow p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Ask me anything about hotel management..." autocomplete="off">
                                <button type="submit" class="btn btn-primary px-4 py-3 rounded-lg">
                                    <i class="fas fa-paper-plane"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script>
        // Chatbot functionality
        document.getElementById('chatForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const userInput = document.getElementById('userInput');
            const message = userInput.value.trim();
            
            if (message) {
                // Add user message to chat
                addMessage(message, 'user');
                userInput.value = '';
                
                // Show typing indicator
                showTypingIndicator();
                
                // Simulate bot response after a delay
                setTimeout(() => {
                    removeTypingIndicator();
                    const botResponse = getBotResponse(message);
                    addMessage(botResponse, 'bot');
                }, 1000 + Math.random() * 2000);
            }
        });
        
        // Quick action buttons
        document.querySelectorAll('.quick-action-btn').forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                const action = this.textContent;
                document.getElementById('userInput').value = action;
                document.getElementById('chatForm').dispatchEvent(new Event('submit'));
            });
        });
        
        function addMessage(text, sender) {
            const chatMessages = document.getElementById('chatMessages');
            const messageDiv = document.createElement('div');
            messageDiv.className = `message ${sender}-message`;
            
            if (sender === 'bot') {
                messageDiv.innerHTML = `<div class="font-bold mb-1">HotelAI</div><div>${text}</div>`;
            } else {
                messageDiv.innerHTML = `<div class="font-bold mb-1">You</div><div>${text}</div>`;
            }
            
            chatMessages.appendChild(messageDiv);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
        
        function showTypingIndicator() {
            const chatMessages = document.getElementById('chatMessages');
            const typingDiv = document.createElement('div');
            typingDiv.className = 'typing-indicator';
            typingDiv.id = 'typingIndicator';
            typingDiv.innerHTML = `
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
                <span class="ml-2 text-gray-500">HotelAI is typing...</span>
            `;
            chatMessages.appendChild(typingDiv);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
        
        function removeTypingIndicator() {
            const typingIndicator = document.getElementById('typingIndicator');
            if (typingIndicator) {
                typingIndicator.remove();
            }
        }
        
        function getBotResponse(userMessage) {
            // This is a simplified version - in a real app, you'd call an API
            const lowerMessage = userMessage.toLowerCase();
            
            if (lowerMessage.includes('availability') || lowerMessage.includes('room')) {
                return "We currently have 12 standard rooms, 5 deluxe rooms, and 3 suites available for the next week. Would you like me to check specific dates?";
            } 
            else if (lowerMessage.includes('reservation') || lowerMessage.includes('booking')) {
                return "To create a new reservation, please provide the guest details and preferred dates. You can also click 'New Reservation' in the Quick Actions section.";
            }
            else if (lowerMessage.includes('check-in') || lowerMessage.includes('arrival')) {
                return "Today's check-ins: 8 confirmed arrivals. 3 have already checked in, 5 are pending. Would you like to see the list?";
            }
            else if (lowerMessage.includes('report') || lowerMessage.includes('revenue')) {
                return "Yesterday's revenue: $24,850 (92% occupancy). Month-to-date: $348,700 (87% occupancy). Would you like the detailed breakdown or comparison to previous periods?";
            }
            else if (lowerMessage.includes('hello') || lowerMessage.includes('hi')) {
                return "Hello! I'm HotelAI, your intelligent hotel management assistant. How can I help you with your hotel operations today?";
            }
            else {
                return "I can help with reservations, room management, guest services, and reports. Please ask me about any aspect of your hotel management, or try one of the quick actions above.";
            }
        }
    </script>
</body>
</html>