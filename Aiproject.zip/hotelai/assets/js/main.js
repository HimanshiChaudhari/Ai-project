/**
 * HotelAI Main JavaScript File
 * Includes all frontend functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            alert.style.transition = 'opacity 0.5s ease';
            alert.style.opacity = '0';
            setTimeout(function() {
                alert.remove();
            }, 500);
        }, 5000);
    });

    // Initialize date pickers
    if (typeof flatpickr !== 'undefined') {
        flatpickr('.datepicker', {
            minDate: 'today',
            maxDate: new Date().fp_incr(365), // 1 year from now
            dateFormat: 'Y-m-d',
            disable: [
                function(date) {
                    // Disable weekends
                    return (date.getDay() === 0 || date.getDay() === 6);
                }
            ]
        });
    }

    // Reservation Form Handling
    const reservationForm = document.getElementById('reservationForm');
    if (reservationForm) {
        reservationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const submitBtn = this.querySelector('[type="submit"]');
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...';

            fetch(this.action, {
                method: this.method,
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    window.location.href = 'reservations.php';
                } else {
                    showFormErrors(data.errors);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            })
            .finally(() => {
                submitBtn.disabled = false;
                submitBtn.innerHTML = 'Create Reservation';
            });
        });
    }

    // Room Availability Check
    const checkInInput = document.getElementById('check_in');
    const checkOutInput = document.getElementById('check_out');
    const roomSelect = document.getElementById('room_id');

    if (checkInInput && checkOutInput && roomSelect) {
        checkInInput.addEventListener('change', checkRoomAvailability);
        checkOutInput.addEventListener('change', checkRoomAvailability);
    }

    // Chatbot functionality
    const chatForm = document.getElementById('chatForm');
    if (chatForm) {
        chatForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const userInput = document.getElementById('userInput');
            const message = userInput.value.trim();
            
            if (message) {
                addMessage(message, 'user');
                userInput.value = '';
                
                showTypingIndicator();
                
                // Simulate API call
                setTimeout(() => {
                    removeTypingIndicator();
                    const botResponse = getBotResponse(message);
                    addMessage(botResponse, 'bot');
                }, 1000 + Math.random() * 2000);
            }
        });
    }

    // Quick action buttons
    document.querySelectorAll('.quick-action-btn').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const action = this.textContent;
            document.getElementById('userInput').value = action;
            document.getElementById('chatForm').dispatchEvent(new Event('submit'));
        });
    });
});

// Helper Functions
function showFormErrors(errors) {
    // Clear previous errors
    document.querySelectorAll('.is-invalid').forEach(el => {
        el.classList.remove('is-invalid');
    });
    document.querySelectorAll('.invalid-feedback').forEach(el => {
        el.remove();
    });

    // Add new errors
    for (const field in errors) {
        const input = document.querySelector(`[name="${field}"]`);
        if (input) {
            input.classList.add('is-invalid');
            const errorDiv = document.createElement('div');
            errorDiv.className = 'invalid-feedback';
            errorDiv.textContent = errors[field];
            input.parentNode.appendChild(errorDiv);
        }
    }
}

function checkRoomAvailability() {
    const checkIn = checkInInput.value;
    const checkOut = checkOutInput.value;
    
    if (checkIn && checkOut) {
        fetch(`api/check_availability.php?check_in=${checkIn}&check_out=${checkOut}`)
            .then(response => response.json())
            .then(data => {
                // Update room select options
                roomSelect.innerHTML = '<option value="">Select Room</option>';
                data.availableRooms.forEach(room => {
                    const option = document.createElement('option');
                    option.value = room.id;
                    option.textContent = `${room.room_number} (${room.room_type}) - $${room.price}/night`;
                    roomSelect.appendChild(option);
                });
            });
    }
}

// Chatbot Functions
function addMessage(text, sender) {
    const chatMessages = document.getElementById('chatMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}-message`;
    
    if (sender === 'bot') {
        messageDiv.innerHTML = `<div class="font-bold mb-1">HotelAI</div><div>${text}</div>`;
    } else {
        messageDiv.innerHTML = `<div class="font-bold mb-1">You</div><div>${text}</div>`;
    }
    
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function showTypingIndicator() {
    const chatMessages = document.getElementById('chatMessages');
    const typingDiv = document.createElement('div');
    typingDiv.className = 'typing-indicator';
    typingDiv.id = 'typingIndicator';
    typingDiv.innerHTML = `
        <div class="typing-dot"></div>
        <div class="typing-dot"></div>
        <div class="typing-dot"></div>
        <span class="ml-2 text-gray-500">HotelAI is typing...</span>
    `;
    chatMessages.appendChild(typingDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function removeTypingIndicator() {
    const typingIndicator = document.getElementById('typingIndicator');
    if (typingIndicator) {
        typingIndicator.remove();
    }
}

function getBotResponse(userMessage) {
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes('availability') || lowerMessage.includes('room')) {
        return "We currently have rooms available. Would you like me to check specific dates for you?";
    } 
    else if (lowerMessage.includes('reservation') || lowerMessage.includes('booking')) {
        return "You can create a new reservation by clicking 'New Reservation' or telling me your preferred dates.";
    }
    else if (lowerMessage.includes('check-in') || lowerMessage.includes('arrival')) {
        return "Today's check-ins will be processed from 3 PM onwards. Need help with a specific guest?";
    }
    else if (lowerMessage.includes('report') || lowerMessage.includes('revenue')) {
        return "I can generate reports for you. Would you like daily, weekly, or monthly reports?";
    }
    else {
        return "I can help with reservations, room management, and reports. What would you like assistance with?";
    }
}