<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

if (isLoggedIn()) {
    header("Location: " . BASE_URL . "/index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error'] = 'Invalid request method';
    header("Location: " . BASE_URL . "/register.php");
    exit();
}

$username = trim($_POST['username']);
$email = trim($_POST['email']);
$password = trim($_POST['password']);
$confirm_password = trim($_POST['confirm_password']);
$full_name = trim($_POST['full_name']);

// Validate inputs
if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
    $_SESSION['error'] = 'Please fill in all required fields';
    header("Location: " . BASE_URL . "/register.php");
    exit();
}

if ($password !== $confirm_password) {
    $_SESSION['error'] = 'Passwords do not match';
    header("Location: " . BASE_URL . "/register.php");
    exit();
}

if (strlen($password) < 6) {
    $_SESSION['error'] = 'Password must be at least 6 characters long';
    header("Location: " . BASE_URL . "/register.php");
    exit();
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $_SESSION['error'] = 'Invalid email format';
    header("Location: " . BASE_URL . "/register.php");
    exit();
}

try {
    // Check if username or email already exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $email]);
    
    if ($stmt->fetch()) {
        $_SESSION['error'] = 'Username or email already exists';
        header("Location: " . BASE_URL . "/register.php");
        exit();
    }

    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $role = 'staff'; // Default role for new registrations
    
    // Insert new user
    $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role, full_name) VALUES (?, ?, ?, ?, ?)");
    $success = $stmt->execute([$username, $email, $hashed_password, $role, $full_name]);

    if ($success) {
        // Get the new user's ID
        $user_id = $pdo->lastInsertId();
        
        // Auto-login the new user
        $_SESSION['user_id'] = $user_id;
        $_SESSION['username'] = $username;
        $_SESSION['role'] = $role;
        $_SESSION['full_name'] = $full_name;
        
        $_SESSION['success'] = 'Registration successful! Welcome to HotelAI';
        header("Location: " . BASE_URL . "/index.php");
        exit();
    } else {
        $_SESSION['error'] = 'Registration failed. Please try again.';
        header("Location: " . BASE_URL . "/register.php");
        exit();
    }
} catch (PDOException $e) {
    error_log("Registration error: " . $e->getMessage());
    $_SESSION['error'] = 'An error occurred during registration. Please try again.';
    header("Location: " . BASE_URL . "/register.php");
    exit();
}
?>