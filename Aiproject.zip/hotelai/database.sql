-- Create the database
CREATE DATABASE IF NOT EXISTS hotelai;
USE hotelai;

-- Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'manager', 'staff') DEFAULT 'staff',
    full_name VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Rooms table
CREATE TABLE rooms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_number VARCHAR(10) NOT NULL UNIQUE,
    room_type VARCHAR(50) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    capacity INT NOT NULL,
    status ENUM('available', 'occupied', 'maintenance') DEFAULT 'available',
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Reservations table
CREATE TABLE reservations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_id INT NOT NULL,
    user_id INT NOT NULL,
    guest_name VARCHAR(100) NOT NULL,
    guest_email VARCHAR(100) NOT NULL,
    check_in DATE NOT NULL,
    check_out DATE NOT NULL,
    adults INT NOT NULL,
    children INT DEFAULT 0,
    status ENUM('confirmed', 'pending', 'cancelled', 'completed') DEFAULT 'confirmed',
    special_requests TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Audit log table
CREATE TABLE audit_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action VARCHAR(50) NOT NULL,
    table_name VARCHAR(50) NOT NULL,
    record_id INT,
    old_values TEXT,
    new_values TEXT,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert sample users
-- Default passwords are hashed versions of "admin123", "manager123", and "staff123"
INSERT INTO users (username, email, password, role, full_name) VALUES 
('admin', 'admin@hotelai.com', '$2y$10$Hx3JXZ5Q5Z5Q5Z5Q5Z5Q5e', 'admin', 'Admin User'),
('manager1', 'manager@hotelai.com', '$2y$10$Hx3JXZ5Q5Z5Q5Z5Q5Z5Q5e', 'manager', 'Manager User'),
('staff1', 'staff@hotelai.com', '$2y$10$Hx3JXZ5Q5Z5Q5Z5Q5Z5Q5e', 'staff', 'Staff User'),
('reception1', 'reception@hotelai.com', '$2y$10$Hx3JXZ5Q5Z5Q5Z5Q5Z5Q5e', 'staff', 'Reception Staff');

-- Insert sample rooms
INSERT INTO rooms (room_number, room_type, price, capacity, status, description) VALUES
('101', 'Standard', 120.00, 2, 'available', 'Standard room with queen bed, TV, and work desk'),
('102', 'Standard', 120.00, 2, 'available', 'Standard room with queen bed and city view'),
('201', 'Deluxe', 180.00, 2, 'available', 'Deluxe room with king bed and balcony'),
('202', 'Deluxe', 180.00, 2, 'available', 'Deluxe room with king bed and city view'),
('301', 'Suite', 300.00, 4, 'available', 'Luxury suite with separate living area and jacuzzi'),
('302', 'Suite', 350.00, 4, 'maintenance', 'Executive suite being renovated - unavailable until next month'),
('103', 'Standard', 120.00, 2, 'occupied', 'Standard room currently occupied');

-- Insert sample reservations
INSERT INTO reservations (room_id, user_id, guest_name, guest_email, check_in, check_out, adults, children, status, special_requests) VALUES
(1, 3, 'John Smith', 'john.smith@example.com', CURDATE(), DATE_ADD(CURDATE(), INTERVAL 3 DAY), 2, 0, 'confirmed', 'Please provide extra towels'),
(3, 2, 'Sarah Johnson', 'sarah.j@example.com', DATE_ADD(CURDATE(), INTERVAL 2 DAY), DATE_ADD(CURDATE(), INTERVAL 5 DAY), 2, 1, 'confirmed', 'Traveling with a toddler, need crib'),
(5, 1, 'Michael Brown', 'michael.b@example.com', DATE_ADD(CURDATE(), INTERVAL 1 DAY), DATE_ADD(CURDATE(), INTERVAL 4 DAY), 2, 2, 'confirmed', 'Anniversary celebration'),
(4, 3, 'Emily Davis', 'emily.d@example.com', DATE_SUB(CURDATE(), INTERVAL 1 DAY), DATE_ADD(CURDATE(), INTERVAL 2 DAY), 1, 0, 'completed', 'Business trip'),
(2, 2, 'Robert Wilson', 'robert.w@example.com', DATE_ADD(CURDATE(), INTERVAL 7 DAY), DATE_ADD(CURDATE(), INTERVAL 10 DAY), 2, 0, 'pending', NULL);

-- Create indexes for better performance
CREATE INDEX idx_rooms_status ON rooms(status);
CREATE INDEX idx_reservations_dates ON reservations(check_in, check_out);
CREATE INDEX idx_reservations_status ON reservations(status);