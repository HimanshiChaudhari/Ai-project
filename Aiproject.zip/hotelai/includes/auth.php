<?php
// includes/auth.php
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function isManager() {
    return isset($_SESSION['role']) && ($_SESSION['role'] === 'manager' || $_SESSION['role'] === 'admin');
}

function redirectIfNotLoggedIn() {
    if (!isLoggedIn()) {
        header("Location: " . BASE_URL . "/login.php");
        exit();
    }
}

function redirectIfNotAdmin() {
    redirectIfNotLoggedIn();
    if (!isAdmin()) {
        header("Location: " . BASE_URL . "/index.php");
        exit();
    }
}

function redirectIfNotManager() {
    redirectIfNotLoggedIn();
    if (!isManager()) {
        header("Location: " . BASE_URL . "/index.php");
        exit();
    }
}
?>