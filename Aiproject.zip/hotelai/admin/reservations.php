<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
redirectIfNotManager();

$action = $_GET['action'] ?? 'list';
$id = $_GET['id'] ?? 0;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_reservation']) || isset($_POST['update_reservation'])) {
        $room_id = (int)$_POST['room_id'];
        $guest_name = trim($_POST['guest_name']);
        $guest_email = trim($_POST['guest_email']);
        $check_in = $_POST['check_in'];
        $check_out = $_POST['check_out'];
        $adults = (int)$_POST['adults'];
        $children = (int)$_POST['children'];
        $status = $_POST['status'];
        
        // Validate inputs
        $errors = [];
        if (empty($room_id)) $errors[] = 'Room is required';
        if (empty($guest_name)) $errors[] = 'Guest name is required';
        if (!filter_var($guest_email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email format';
        if (empty($check_in) || empty($check_out)) $errors[] = 'Dates are required';
        if (strtotime($check_in) >= strtotime($check_out)) $errors[] = 'Check-out must be after check-in';
        if ($adults <= 0) $errors[] = 'At least one adult required';

        if (empty($errors)) {
            try {
                if (isset($_POST['create_reservation'])) {
                    $stmt = $pdo->prepare("INSERT INTO reservations (room_id, user_id, guest_name, guest_email, check_in, check_out, adults, children, status) 
                                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $success = $stmt->execute([$room_id, $_SESSION['user_id'], $guest_name, $guest_email, $check_in, $check_out, $adults, $children, $status]);
                    
                    if ($success && $status === 'confirmed') {
                        $pdo->prepare("UPDATE rooms SET status = 'occupied' WHERE id = ?")->execute([$room_id]);
                    }
                    
                    $_SESSION['success'] = 'Reservation created successfully!';
                } else {
                    // Update logic here
                }
                
                header("Location: reservations.php");
                exit();
            } catch (PDOException $e) {
                $errors[] = "Database error: " . $e->getMessage();
            }
        }
    }
}

// Get available rooms
$availableRooms = $pdo->query("SELECT * FROM rooms WHERE status = 'available' ORDER BY room_number")->fetchAll();

// Get all reservations
$reservations = $pdo->query("
    SELECT r.*, rm.room_number, rm.room_type 
    FROM reservations r 
    JOIN rooms rm ON r.room_id = rm.id 
    ORDER BY r.created_at DESC
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include '../includes/header.php'; ?>
    <title>Manage Reservations</title>
    <style>
        .datepicker { z-index: 10000 !important; }
    </style>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <main class="container py-4">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $error): ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <?php if ($action === 'create'): ?>
            <h2>Create New Reservation</h2>
            <div class="card">
                <div class="card-body">
                    <form method="POST">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Room</label>
                                <select name="room_id" class="form-select" required>
                                    <option value="">Select Room</option>
                                    <?php foreach ($availableRooms as $room): ?>
                                        <option value="<?= $room['id'] ?>">
                                            <?= htmlspecialchars($room['room_number']) ?> (<?= htmlspecialchars($room['room_type']) ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Status</label>
                                <select name="status" class="form-select" required>
                                    <option value="confirmed">Confirmed</option>
                                    <option value="pending">Pending</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Guest Name</label>
                                <input type="text" name="guest_name" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Guest Email</label>
                                <input type="email" name="guest_email" class="form-control" required>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Check-in Date</label>
                                <input type="date" name="check_in" class="form-control datepicker" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Check-out Date</label>
                                <input type="date" name="check_out" class="form-control datepicker" required>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Adults</label>
                                <input type="number" name="adults" class="form-control" min="1" value="1" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Children</label>
                                <input type="number" name="children" class="form-control" min="0" value="0">
                            </div>
                        </div>
                        
                        <button type="submit" name="create_reservation" class="btn btn-primary">Create Reservation</button>
                        <a href="reservations.php" class="btn btn-secondary">Cancel</a>
                    </form>
                </div>
            </div>
            
        <?php else: ?>
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Manage Reservations</h2>
                <a href="reservations.php?action=create" class="btn btn-primary">
                    <i class="fas fa-plus"></i> New Reservation
                </a>
            </div>
            
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Room</th>
                                    <th>Guest</th>
                                    <th>Dates</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($reservations as $res): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($res['room_number']) ?> (<?= htmlspecialchars($res['room_type']) ?>)</td>
                                        <td><?= htmlspecialchars($res['guest_name']) ?></td>
                                        <td><?= date('M j', strtotime($res['check_in'])) ?> - <?= date('M j', strtotime($res['check_out'])) ?></td>
                                        <td>
                                            <span class="badge bg-<?= $res['status'] === 'confirmed' ? 'success' : 'warning' ?>">
                                                <?= ucfirst($res['status']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="reservations.php?action=view&id=<?= $res['id'] ?>" class="btn btn-sm btn-outline-info">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="reservations.php?action=edit&id=<?= $res['id'] ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </main>

    <?php include '../includes/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script>
        // Initialize date pickers
        flatpickr('.datepicker', {
            minDate: 'today',
            dateFormat: 'Y-m-d'
        });
    </script>
</body>
</html>