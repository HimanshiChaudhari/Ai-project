<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
redirectIfNotManager();

// Dashboard statistics
$totalRooms = $pdo->query("SELECT COUNT(*) FROM rooms")->fetchColumn();
$availableRooms = $pdo->query("SELECT COUNT(*) FROM rooms WHERE status = 'available'")->fetchColumn();
$todayCheckIns = $pdo->query("SELECT COUNT(*) FROM reservations WHERE check_in = CURDATE()")->fetchColumn();
$monthRevenue = $pdo->query("SELECT SUM(rooms.price) FROM reservations JOIN rooms ON reservations.room_id = rooms.id WHERE check_in BETWEEN DATE_FORMAT(NOW() ,'%Y-%m-01') AND LAST_DAY(NOW())")->fetchColumn();

// Recent reservations
$reservations = $pdo->query("SELECT r.*, rm.room_number, rm.room_type FROM reservations r JOIN rooms rm ON r.room_id = rm.id ORDER BY r.created_at DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php $pageTitle = "Admin Dashboard"; ?>
    <?php include '../includes/header.php'; ?>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <main class="container py-4">
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card text-white bg-primary">
                    <div class="card-body">
                        <h5 class="card-title">Total Rooms</h5>
                        <h2 class="card-text"><?php echo $totalRooms; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-success">
                    <div class="card-body">
                        <h5 class="card-title">Available Rooms</h5>
                        <h2 class="card-text"><?php echo $availableRooms; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-info">
                    <div class="card-body">
                        <h5 class="card-title">Today's Check-ins</h5>
                        <h2 class="card-text"><?php echo $todayCheckIns; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-warning">
                    <div class="card-body">
                        <h5 class="card-title">Month Revenue</h5>
                        <h2 class="card-text">$<?php echo number_format($monthRevenue, 2); ?></h2>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5>Recent Reservations</h5>
                <a href="reservations.php" class="btn btn-sm btn-outline-primary">View All</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Room</th>
                                <th>Guest</th>
                                <th>Dates</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($reservations as $res): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($res['room_number']); ?> (<?php echo htmlspecialchars($res['room_type']); ?>)</td>
                                    <td><?php echo htmlspecialchars($res['guest_name']); ?></td>
                                    <td><?php echo date('M j', strtotime($res['check_in'])); ?> - <?php echo date('M j', strtotime($res['check_out'])); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo $res['status'] === 'confirmed' ? 'success' : ($res['status'] === 'cancelled' ? 'danger' : 'warning'); ?>">
                                            <?php echo ucfirst($res['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="reservations.php?action=view&id=<?php echo $res['id']; ?>" class="btn btn-sm btn-outline-info">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <?php if (isAdmin()): ?>
                                        <a href="reservations.php?action=edit&id=<?php echo $res['id']; ?>" class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <?php include '../includes/footer.php'; ?>
</body>
</html>