<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
redirectIfNotManager();

$action = $_GET['action'] ?? 'list';
$id = $_GET['id'] ?? 0;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($action === 'add' || $action === 'edit') {
        $room_number = trim($_POST['room_number']);
        $room_type = trim($_POST['room_type']);
        $price = trim($_POST['price']);
        $capacity = trim($_POST['capacity']);
        $status = trim($_POST['status']);
        $description = trim($_POST['description']);
        
        // Validate inputs
        $errors = [];
        if (empty($room_number)) $errors[] = 'Room number is required';
        if (empty($room_type)) $errors[] = 'Room type is required';
        if (!is_numeric($price) || $price <= 0) $errors[] = 'Price must be a positive number';
        if (!is_numeric($capacity) || $capacity <= 0) $errors[] = 'Capacity must be a positive number';
        
        if (empty($errors)) {
            if ($action === 'add') {
                $stmt = $pdo->prepare("INSERT INTO rooms (room_number, room_type, price, capacity, status, description) VALUES (?, ?, ?, ?, ?, ?)");
                $success = $stmt->execute([$room_number, $room_type, $price, $capacity, $status, $description]);
                $message = $success ? 'Room added successfully!' : 'Failed to add room';
            } else {
                $stmt = $pdo->prepare("UPDATE rooms SET room_number = ?, room_type = ?, price = ?, capacity = ?, status = ?, description = ? WHERE id = ?");
                $success = $stmt->execute([$room_number, $room_type, $price, $capacity, $status, $description, $id]);
                $message = $success ? 'Room updated successfully!' : 'Failed to update room';
            }
            
            if ($success) {
                $_SESSION['success'] = $message;
                header("Location: rooms.php");
                exit();
            }
        }
    } elseif ($action === 'delete') {
        $stmt = $pdo->prepare("DELETE FROM rooms WHERE id = ?");
        $success = $stmt->execute([$id]);
        $_SESSION['success'] = $success ? 'Room deleted successfully!' : 'Failed to delete room';
        header("Location: rooms.php");
        exit();
    }
}

// Get room data for edit
$room = [];
if ($action === 'edit' || $action === 'view') {
    $stmt = $pdo->prepare("SELECT * FROM rooms WHERE id = ?");
    $stmt->execute([$id]);
    $room = $stmt->fetch();
    
    if (!$room) {
        $_SESSION['error'] = 'Room not found';
        header("Location: rooms.php");
        exit();
    }
}

// Get all rooms for listing
$rooms = $pdo->query("SELECT * FROM rooms ORDER BY room_number")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php $pageTitle = "Manage Rooms"; ?>
    <?php include '../includes/header.php'; ?>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <main class="container py-4">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>
        
        <?php if (isset($errors) && !empty($errors)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo $error; ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <?php if ($action === 'list'): ?>
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Manage Rooms</h2>
                <a href="rooms.php?action=add" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Add Room
                </a>
            </div>
            
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Room #</th>
                                    <th>Type</th>
                                    <th>Price</th>
                                    <th>Capacity</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($rooms as $r): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($r['room_number']); ?></td>
                                        <td><?php echo htmlspecialchars($r['room_type']); ?></td>
                                        <td>$<?php echo number_format($r['price'], 2); ?></td>
                                        <td><?php echo $r['capacity']; ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo $r['status'] === 'available' ? 'success' : ($r['status'] === 'occupied' ? 'danger' : 'warning'); ?>">
                                                <?php echo ucfirst($r['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="rooms.php?action=view&id=<?php echo $r['id']; ?>" class="btn btn-sm btn-outline-info">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="rooms.php?action=edit&id=<?php echo $r['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="rooms.php?action=delete&id=<?php echo $r['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
        <?php elseif ($action === 'add' || $action === 'edit'): ?>
            <h2><?php echo $action === 'add' ? 'Add New Room' : 'Edit Room'; ?></h2>
            
            <div class="card">
                <div class="card-body">
                    <form method="POST">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="room_number" class="form-label">Room Number</label>
                                <input type="text" class="form-control" id="room_number" name="room_number" 
                                       value="<?php echo htmlspecialchars($room['room_number'] ?? ''); ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label for="room_type" class="form-label">Room Type</label>
                                <select class="form-select" id="room_type" name="room_type" required>
                                    <option value="">Select Type</option>
                                    <option value="Standard" <?php echo isset($room['room_type']) && $room['room_type'] === 'Standard' ? 'selected' : ''; ?>>Standard</option>
                                    <option value="Deluxe" <?php echo isset($room['room_type']) && $room['room_type'] === 'Deluxe' ? 'selected' : ''; ?>>Deluxe</option>
                                    <option value="Suite" <?php echo isset($room['room_type']) && $room['room_type'] === 'Suite' ? 'selected' : ''; ?>>Suite</option>
                                </select>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="price" class="form-label">Price per Night</label>
                                <div class="input-group">
                                    <span class="input-group-text">$</span>
                                    <input type="number" class="form-control" id="price" name="price" 
                                           value="<?php echo htmlspecialchars($room['price'] ?? ''); ?>" step="0.01" min="0" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="capacity" class="form-label">Capacity</label>
                                <input type="number" class="form-control" id="capacity" name="capacity" 
                                       value="<?php echo htmlspecialchars($room['capacity'] ?? ''); ?>" min="1" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="status" class="form-label">Status</label>
                                <select class="form-select" id="status" name="status" required>
                                    <option value="available" <?php echo isset($room['status']) && $room['status'] === 'available' ? 'selected' : ''; ?>>Available</option>
                                    <option value="occupied" <?php echo isset($room['status']) && $room['status'] === 'occupied' ? 'selected' : ''; ?>>Occupied</option>
                                    <option value="maintenance" <?php echo isset($room['status']) && $room['status'] === 'maintenance' ? 'selected' : ''; ?>>Maintenance</option>
                                </select>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="3"><?php echo htmlspecialchars($room['description'] ?? ''); ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Save</button>
                        <a href="rooms.php" class="btn btn-secondary">Cancel</a>
                    </form>
                </div>
            </div>
            
        <?php elseif ($action === 'view'): ?>
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Room Details</h2>
                <div>
                    <a href="rooms.php?action=edit&id=<?php echo $room['id']; ?>" class="btn btn-primary">
                        <i class="fas fa-edit"></i> Edit
                    </a>
                    <a href="rooms.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back
                    </a>
                </div>
            </div>
            
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h5 class="card-title"><?php echo htmlspecialchars($room['room_number']); ?> - <?php echo htmlspecialchars($room['room_type']); ?></h5>
                            <p class="card-text"><?php echo htmlspecialchars($room['description']); ?></p>
                        </div>
                        <div class="col-md-6">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>Status:</span>
                                    <span class="badge bg-<?php echo $room['status'] === 'available' ? 'success' : ($room['status'] === 'occupied' ? 'danger' : 'warning'); ?>">
                                        <?php echo ucfirst($room['status']); ?>
                                    </span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>Price per Night:</span>
                                    <span>$<?php echo number_format($room['price'], 2); ?></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>Capacity:</span>
                                    <span><?php echo $room['capacity']; ?> person(s)</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </main>

    <?php include '../includes/footer.php'; ?>
</body>
</html>