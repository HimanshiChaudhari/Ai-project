<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
redirectIfNotAdmin();

$action = $_GET['action'] ?? 'list';
$id = $_GET['id'] ?? 0;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($action === 'add' || $action === 'edit') {
        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        $full_name = trim($_POST['full_name']);
        $role = trim($_POST['role']);
        $password = trim($_POST['password']);
        $confirm_password = trim($_POST['confirm_password']);
        
        // Validate inputs
        $errors = [];
        if (empty($username)) $errors[] = 'Username is required';
        if (empty($email)) $errors[] = 'Email is required';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email format';
        if (empty($role)) $errors[] = 'Role is required';
        
        // Password validation for add or when changing password
        if ($action === 'add' || !empty($password)) {
            if (empty($password)) {
                $errors[] = 'Password is required';
            } elseif (strlen($password) < 6) {
                $errors[] = 'Password must be at least 6 characters';
            } elseif ($password !== $confirm_password) {
                $errors[] = 'Passwords do not match';
            }
        }
        
        if (empty($errors)) {
            // Check if username or email already exists (for add or when changed in edit)
            $stmt = $pdo->prepare("SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?");
            $stmt->execute([$username, $email, $id]);
            if ($stmt->fetch()) {
                $errors[] = 'Username or email already exists';
            } else {
                if ($action === 'add') {
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role, full_name) VALUES (?, ?, ?, ?, ?)");
                    $success = $stmt->execute([$username, $email, $hashed_password, $role, $full_name]);
                    $message = $success ? 'Staff member added successfully!' : 'Failed to add staff member';
                } else {
                    if (!empty($password)) {
                        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                        $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, password = ?, role = ?, full_name = ? WHERE id = ?");
                        $success = $stmt->execute([$username, $email, $hashed_password, $role, $full_name, $id]);
                    } else {
                        $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, role = ?, full_name = ? WHERE id = ?");
                        $success = $stmt->execute([$username, $email, $role, $full_name, $id]);
                    }
                    $message = $success ? 'Staff member updated successfully!' : 'Failed to update staff member';
                }
                
                if ($success) {
                    $_SESSION['success'] = $message;
                    header("Location: staff.php");
                    exit();
                }
            }
        }
    } elseif ($action === 'delete') {
        // Prevent deleting own account
        if ($id == $_SESSION['user_id']) {
            $_SESSION['error'] = 'You cannot delete your own account';
        } else {
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $success = $stmt->execute([$id]);
            $_SESSION['success'] = $success ? 'Staff member deleted successfully!' : 'Failed to delete staff member';
        }
        header("Location: staff.php");
        exit();
    }
}

// Get staff data for edit/view
$staff = [];
if ($action === 'edit' || $action === 'view') {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $staff = $stmt->fetch();
    
    if (!$staff) {
        $_SESSION['error'] = 'Staff member not found';
        header("Location: staff.php");
        exit();
    }
}

// Get all staff for listing
$staffMembers = $pdo->query("SELECT * FROM users ORDER BY role, username")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php $pageTitle = "Manage Staff"; ?>
    <?php include '../includes/header.php'; ?>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <main class="container py-4">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>
        
        <?php if (isset($errors) && !empty($errors)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo $error; ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <?php if ($action === 'list'): ?>
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Manage Staff</h2>
                <a href="staff.php?action=add" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Add Staff
                </a>
            </div>
            
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Username</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($staffMembers as $member): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($member['username']); ?></td>
                                        <td><?php echo htmlspecialchars($member['full_name']); ?></td>
                                        <td><?php echo htmlspecialchars($member['email']); ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo $member['role'] === 'admin' ? 'danger' : ($member['role'] === 'manager' ? 'warning' : 'primary'); ?>">
                                                <?php echo ucfirst($member['role']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="staff.php?action=view&id=<?php echo $member['id']; ?>" class="btn btn-sm btn-outline-info">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="staff.php?action=edit&id=<?php echo $member['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <?php if ($member['id'] != $_SESSION['user_id']): ?>
                                            <a href="staff.php?action=delete&id=<?php echo $member['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
        <?php elseif ($action === 'add' || $action === 'edit'): ?>
            <h2><?php echo $action === 'add' ? 'Add Staff Member' : 'Edit Staff Member'; ?></h2>
            
            <div class="card">
                <div class="card-body">
                    <form method="POST">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" class="form-control" id="username" name="username" 
                                       value="<?php echo htmlspecialchars($staff['username'] ?? ''); ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" 
                                       value="<?php echo htmlspecialchars($staff['email'] ?? ''); ?>" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="full_name" class="form-label">Full Name</label>
                                <input type="text" class="form-control" id="full_name" name="full_name" 
                                       value="<?php echo htmlspecialchars($staff['full_name'] ?? ''); ?>">
                            </div>
                            <div class="col-md-6">
                                <label for="role" class="form-label">Role</label>
                                <select class="form-select" id="role" name="role" required>
                                    <option value="">Select Role</option>
                                    <option value="admin" <?php echo isset($staff['role']) && $staff['role'] === 'admin' ? 'selected' : ''; ?>>Admin</option>
                                    <option value="manager" <?php echo isset($staff['role']) && $staff['role'] === 'manager' ? 'selected' : ''; ?>>Manager</option>
                                    <option value="staff" <?php echo isset($staff['role']) && $staff['role'] === 'staff' ? 'selected' : ''; ?>>Staff</option>
                                </select>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="password" class="form-label"><?php echo $action === 'add' ? 'Password' : 'New Password'; ?></label>
                                <input type="password" class="form-control" id="password" name="password" 
                                       <?php echo $action === 'add' ? 'required' : ''; ?>>
                            </div>
                            <div class="col-md-6">
                                <label for="confirm_password" class="form-label">Confirm Password</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" 
                                       <?php echo $action === 'add' ? 'required' : ''; ?>>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Save</button>
                        <a href="staff.php" class="btn btn-secondary">Cancel</a>
                    </form>
                </div>
            </div>
            
        <?php elseif ($action === 'view'): ?>
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Staff Details</h2>
                <div>
                    <a href="staff.php?action=edit&id=<?php echo $staff['id']; ?>" class="btn btn-primary">
                        <i class="fas fa-edit"></i> Edit
                    </a>
                    <a href="staff.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back
                    </a>
                </div>
            </div>
            
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4 text-center">
                            <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($staff['full_name'] ?? $staff['username']); ?>&background=random" 
                                 class="rounded-circle mb-3" width="150" height="150">
                            <h4><?php echo htmlspecialchars($staff['full_name'] ?? $staff['username']); ?></h4>
                            <span class="badge bg-<?php echo $staff['role'] === 'admin' ? 'danger' : ($staff['role'] === 'manager' ? 'warning' : 'primary'); ?>">
                                <?php echo ucfirst($staff['role']); ?>
                            </span>
                        </div>
                        <div class="col-md-8">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>Username:</span>
                                    <span><?php echo htmlspecialchars($staff['username']); ?></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>Email:</span>
                                    <span><?php echo htmlspecialchars($staff['email']); ?></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>Account Created:</span>
                                    <span><?php echo date('M j, Y', strtotime($staff['created_at'])); ?></span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </main>

    <?php include '../includes/footer.php'; ?>
</body>
</html>